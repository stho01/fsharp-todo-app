﻿Write-Output "Starting node-sass watch. Setting working directory to $PSScriptRoot"
Set-Location $PSScriptRoot

node-sass main.scss > ..\..\WebRoot\style\main.css --watch --recursive --source-map true